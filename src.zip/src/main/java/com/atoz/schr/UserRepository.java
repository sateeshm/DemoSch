//package com.atoz.schr;
//
//import java.util.List;
//
//import org.springframework.data.repository.CrudRepository;
//import org.springframework.data.repository.query.Param;
//import org.springframework.data.rest.core.annotation.RepositoryRestResource;
//
////(collectionResourceRel = "users", path = "users" )
//
//@RepositoryRestResource
//public interface UserRepository extends CrudRepository<User, Integer> {
//	
//	//List<User> findAll();
//	List<User> findById(@Param("id") Integer id);
//	//void deleteById(@Param("id") Integer id);
//	
//}
